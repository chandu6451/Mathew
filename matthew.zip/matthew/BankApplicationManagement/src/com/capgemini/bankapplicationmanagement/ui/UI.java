package com.capgemini.bankapplicationmanagement.ui;

import java.util.Random;
import java.util.Scanner;

import com.capgemini.bankapplicationmanagement.bean.Customers;
import com.capgemini.bankapplicationmanagement.service.bamserviceImp;

public class UI {

	public static void main(String[] args) {
		bamserviceImp service = new bamserviceImp();
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome to the Payemnt Wallet:");
		System.out.println("1.Create Accouont:");

		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.withdraw");
		System.out.println("5.Fund transaction");
		System.out.println("6.Print Transaction");
		System.out.println("7.exit");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter your Name:");
			String cname = sc.next();
			System.out.println("Enter your ID:");
			int cid = sc.nextInt();
			System.out.println("Enter Your MobileNo:");
			long mobNo = sc.nextLong();
			System.out.println("Enter your Gender:");
			String Gender = sc.next();
			System.out.println("Enter your Age:");
			int age = sc.nextInt();
			System.out.println("Enter your AAdhar Number:");
			long gid = sc.nextInt();
			System.out.println("Enter your E-mail Id:");
			String mailId = sc.next();
			Random rnd = new Random();
			int accountNo = 100000 + rnd.nextInt(900000);
			System.out.println(accountNo);

			Random rnd2 = new Random();
			int pin = 1000 + rnd.nextInt(9000);
			System.out.println(pin);

			System.out.println("enter initial balance");
			double balance = sc.nextInt();

			// handing objects to bean object after taking input from user
			Customers bean = new Customers();

			bean.setCname(cname);

			/*
			 * if(isValid) {
			 */double a = bean.getAccNo();
			boolean isAdded = service.addCustomers(a, bean);
			// if(isAdded)
			// {
			System.out.println("account created !");
			System.out.println(bean);
			// }
			/*
			 * else { System.out.println("account NOT created!"); }
			 */

			/*
			 * //} //else //{
			 * System.out.println("invalid data, please enter correct data"); //
			 * System.out.println(bean); }
			 */

			System.out.println("Succesfully registered");

			break;

		case 2:
			System.out.println("Enter your Account Number:");
			long accNO = sc.nextLong();
			System.out.println("Enter your Pin:");
			int pin1 = sc.nextInt();

			System.out.println("enter account number and pin to show balance");

			System.out.println("enter account number");
			long accountNo2 = sc.nextLong();

			System.out.println("enter pin");
			int pin2 = sc.nextInt();

			// boolean valid = service.validateCid(id);
			boolean valid = true;

			if (valid) {
				Customers c = service.displayCustomer(accountNo2, pin2);
				break;

			}
		
		case 3:
			 
		//	StringBuffer sb = new StringBuffer();
			
			/*Customer ca = new Customer();
			StringBuffer sb = ca.getSb();*/
			System.out.println("enter account number and amount to be deposited");
			
			System.out.println("enter account no");
			long accountNo3 = sc.nextLong();
			
			System.out.println("enter amount to be deposited");
			double depositAmount = sc.nextDouble();
			
		
			Customers c = service.deposit(accountNo3, depositAmount, sc);
			System.out.println("your balance is now: ");
			System.out.println(c.getBalance());
			
			
			
			break;
			
		case 4:
            System.out.println("enter account number and pin to proceed");
			
			System.out.println("enter account number");
			long accountNo4 = sc.nextLong();

			System.out.println("enter pin");
			int pin4 = sc.nextInt();
			
			System.out.println("enter amount to be withdrawn");
			double withdrawAmount = sc.nextDouble();
			
			Customers c1 = service.withdraw(accountNo4 , pin4 , withdrawAmount, sc);
			System.out.println("your balance is now: ");
			System.out.println(c1.getBalance());
			
			break;

	
		case 5 :
		System.out.println("enter your account number");
		long accountNo5 = sc.nextLong();
		
		System.out.println("enter your pin");
		int pin5 = sc.nextInt();
		
		System.out.println("enter account number to which you want to transfer amount");
		long accountNoTransfer = sc.nextLong();
		
		System.out.println("enter amount");
		double amountTransfer = sc.nextDouble();
		
		
		Customers c2 = service.fundTransfer(accountNo5 , pin5 , accountNoTransfer , amountTransfer, sc );
		//System.out.println("amount transfered to: " + c2.getAccountNo());
		System.out.println("amount transfered to: " + accountNoTransfer);
		//System.out.println("balance: " + c2.getBalance());
		
		
		
		
		break;
		case 6:
			System.out.println("enter account number and pin to print transactions");
			
			System.out.println("enter your account number");
			long accountNo6 = sc.nextLong();
			
			System.out.println("enter your pin");
			int pin6 = sc.nextInt();
			
			Customers c3 = service.printTransactions(accountNo6 , pin6);
			System.out.println("c3" + c3);
			
			break;
		case 7:
			System.exit(0);
			
			break;
		default:
			break;
		}

	}
		
	


}


