package com.capgemini.bankapplicationmanagement.bean;

public class Customers {
	private String cname;
	private int cid;
	private long mobNo;
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	private  char Gender;
	private  long gid;
	private int age;
	private String mailID;
	private double accNo;
	private int pin;
	private String addr;
	public double getAccNo() {
		return accNo;
	}
	public void setAccNo(double accNo) {
		this.accNo = accNo;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public void setGid(long gid) {
		this.gid = gid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getMailID() {
		return mailID;
	}
	public void setMailID(String mailID) {
		this.mailID = mailID;
	}
	public long getMobNo() {
		return mobNo;
	}
	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	public int getGid() {
		return (int) gid;
	}
	public void setGid(int gid) {
		this.gid = gid;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Customers [cname=" + cname + ", cid=" + cid + ", mobNo="
				+ mobNo + ", Gender=" + Gender + ", gid=" + gid + ", age="
				+ age + ", mailID=" + mailID + ", accNo=" + accNo + ", pin="
				+ pin + ", addr=" + addr + "]";
	}
	public double getBalance() {
		// TODO Auto-generated method stub
		return getBalance();
	}
	public void setBalance(double amt) {
		// TODO Auto-generated method stub
		
	}
	public StringBuffer getSb() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	}
