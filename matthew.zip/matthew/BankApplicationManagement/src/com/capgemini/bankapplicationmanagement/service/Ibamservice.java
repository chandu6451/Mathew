package com.capgemini.bankapplicationmanagement.service;


import java.util.Scanner;

import com.capgemini.bankapplicationmanagement.bean.Customers;

public interface Ibamservice {

	
	
	boolean addCustomers(double accNo, Customers c);
	
	
	
		

	Customers displayCustomer(long accountNo2, int cid);





	Customers printTransactions(long accountNo, int pin);
}