package com.capgemini.bankapplicationmanagement.service;

import java.util.Scanner;

import com.capgemini.bankapplicationmanagement.bean.Customers;
import com.capgemini.bankapplicationmanagement.dao.bamDAOImp;


public  class bamserviceImp implements Ibamservice {
	bamDAOImp dao=new bamDAOImp();



	public boolean addCustomers(double a, Customers bean) {
		// TODO Auto-generated method stub
		return false;
	}

	


	public boolean isValidEmailAddress(String mailId) {
		// TODO Auto-generated method stub
		return false;
	}

	

	

	public Customers displayCustomer(long accountNo2, int cid) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customers deposit(long accountNo3, double depositAmount, Scanner sc) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customers withdraw(long accountNo4, int pin4, double withdrawAmount,
			Scanner sc) {
		// TODO Auto-generated method stub
		return null;
	}

	public Customers printTransactions(long accountNo, int pin) {
		// TODO Auto-generated method stub
		return null;
	}




	public Customers fundTransfer(long accountNo5, int pin5,
			long accountNoTransfer, double amountTransfer, Scanner sc) {
		// TODO Auto-generated method stub
		return null;
	}








	}


	
	

	
	
