package com.capgemini.bankapplicationmanagement.dao;
import com.capgemini.bankapplicationmanagement.bean.Customers;

public interface IbamDAO {
	 
	
		
		boolean addCustomers(long accNo, Customers c);

		public Customers displayCustomer(long accountNo, int pin);
		public Customers printTransactions(long accountNo , int pin);
}
